# server_energy_datasets

服务器能耗数据集

参考论文：

* Ziyu Shen, Xusheng Zhang, Bin Xia, Zheng Liu, Yun Li*:Multi-Granularity Power Prediction for Data Center Operations via Long Short-Term Memory Network. IEEE Intl Conf. on Parallel & Distributed Processing with Applications, ISPA 2019: 194-201, 2019.
* Ziyu Shen, Xusheng Zhang, Binghui Liu, Bin Xia, Zheng Liu, Yun Li*, Saiqin Long:PCP-2LSTM: Two Stacked LSTM-Based Prediction Model for Power Consumption in Data Centers. Seventh International Conference on Advanced Cloud and Big Data, CBD 2019: 13-18, 2019.
* 周清, 张諝晟, 沈子钰,等. 数据中心内服务器能耗数据采集及特征分析[J]. 数据采集与处理, 2021, 36(5):10.